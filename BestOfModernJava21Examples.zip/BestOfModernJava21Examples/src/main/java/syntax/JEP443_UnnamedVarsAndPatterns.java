package syntax;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.IntBinaryOperator;
import java.util.function.IntFunction;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021/22/23 by Michael Inden
 */
public class JEP443_UnnamedVarsAndPatterns {

    record Point(int x, int y) { }
    
    enum Color { RED, GREEN, BLUE }

    record ColoredPoint(Point p, Color c) { }

    record Order(String product) {}

    public static void main(String[] args) {

        motivation();

        unusedVar();

        unnamedPatternAndVars();

        specialMultiUndescoreInSwitch();

    }

    private static void specialMultiUndescoreInSwitch() {
        Object obj = "LDM";
        switch (obj) {
            case Byte _, Short _, Integer _, Long _ -> System.out.println("Input is a number");
            case Float _, Double _ -> System.out.println("Input is a floating-point number");
            case String _ -> System.out.println("Input is a string");
            default -> System.out.println("Object type not expected");
        }
    }

    private static void unnamedPatternAndVars() {
        // unnamed pattern variable
        Point p1 = new Point(3, 4);
        var cp = new ColoredPoint(p1, Color.GREEN);

        if (p1 instanceof Point(int x, int _))
        {
            System.out.println("x: " + x);
        }

        // unnamed pattern variable
        if (cp instanceof ColoredPoint(Point p, Color _)) {
            System.out.println(p);
        }

        // multiple _ and mixed with and without type
        if (cp instanceof ColoredPoint(Point(int x, var _), Color _)) {
            System.out.println(x);
        }

        // unnamed pattern
        if (cp instanceof ColoredPoint(Point(int x, _), _)) {
            System.out.println("unnamed pattern, x: " + x);
        }
    }

    private static void unusedVar() {

        BiFunction<String, String, String> doubleFirst =
                (String str1, String _) -> str1.repeat(2);

        interface IntTriFunction
        {
            int apply(int x, int y, int z);
        }
        IntTriFunction addFirstTwo = (int x, int y, int _) -> x + y;

        IntTriFunction doubleSecond = (int _, int y, int _) -> y * 2;

        try
        {
            Files.writeString(Path.of("UnnamedVars.txt"), "Underscore");
        }
        catch (IOException _)
        {
            // java: Ab Release 21 ist nur das Unterstrichschlüsselwort "_" zulässig, um
            //  unbenannte Muster, lokale Variablen, Ausnahmeparameter oder Lambda-Parameter zu deklarieren
            //_.printStackTrace();
        }

        String userInput = "E605";
        try
        {
            processInput(Integer.parseInt(userInput));
        }
        catch (NumberFormatException _)
        {
            System.out.println("Expected number, but was: '" + userInput + "'");
        }

        int LIMIT = 1000;
        int total = 0;
        List<Order> orders = List.of(new Order("iPhone"), new Order("Pizza"), new Order("Water"));

        for (var _ : orders) {
            if (total < LIMIT) {
                total++;
            }
        }
        System.out.println("total" + total);
    }

    private static void processInput(int i) {
    }

    private static void motivation() {

        record Point(int x, int y) { }

        enum Color { RED, GREEN, BLUE }

        record ColoredPoint(Point p, Color c) { }

        Object obj = new Point(23, 11);

        // Pattern Matching
        if (obj instanceof Point point)
        {
            int x = point.x();
            int y = point.y();

            System.out.println("x: %d y: %d, sum: %d".formatted(x, y, x + y));
        }

        // Record Pattern
        if (obj instanceof Point(int x, int y))
        {
            System.out.println("x: %d y: %d, sum: %d".formatted(x, y, x + y));
        }

        // "old" style
        Point p3_4 = new Point(3, 4);
        var green_p3_4 = new ColoredPoint(p3_4, Color.GREEN);

        if (green_p3_4 instanceof ColoredPoint(Point point, Color color)) {
            System.out.println("x = " + point.x());
        }

        if (green_p3_4 instanceof ColoredPoint(Point(int x, int y), Color color)) {
            System.out.println("x = " + x);
        }

        interface IntTriFunction
        {
            int apply(int x, int y, int z);
        }
        IntTriFunction addFirstTwo = (int x, int y, int z) -> x + y; // z nicht verwendet
        BiFunction<String, String, String> doubleFirst = (String str1, String str2) -> str1.repeat(2); // str2 nicht verwendet

        try
        {
            Files.writeString(Path.of("UnnamedVars.txt"), "Underscore");
        }
        catch (IOException ex)
        {
            // just some logging
        }

        // VERY SPECIAL CASE
        IntFunction<Integer> alwaysZero = (value) -> 0;
        IntFunction<Integer> alwaysZero2 = value -> 0;
        IntFunction<Integer> alwaysZero3 = _ -> 0;
    }
}
