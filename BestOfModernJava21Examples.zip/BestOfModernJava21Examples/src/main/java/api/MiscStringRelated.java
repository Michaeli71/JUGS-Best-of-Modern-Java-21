package api;

import java.util.Arrays;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021/22/23 by Michael Inden
 */
public class MiscStringRelated 
{
    public static void main(final String[] args) 
    {
        var buffer = new StringBuffer();
        buffer.repeat(12345, 5);
        buffer.repeat(721971, 5);
        System.out.println(buffer);

        var booAndFoo = "boo:::and::foo";
        String[] splits = booAndFoo.splitWithDelimiters(":+", 3);
        System.out.println("splits = " + Arrays.toString(splits));
    }
}
