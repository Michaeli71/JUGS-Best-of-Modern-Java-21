package api;
import java.time.Duration;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *         <p>
 * Copyright 2023, 2024 by Michael Inden
 */
public class VirtualThreadsPoolingExample
{
    public static void main(final String[] args)
    {
        for (int i = 1; i < 6; i++) {
            try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
                measureExecution(executor, "Virtual", i);
            }

            try (var executor = Executors.newFixedThreadPool(1000)) {
                measureExecution(executor, "Pooled Plattform", i);
            }

            try (var executor = Executors.newCachedThreadPool()) {
                measureExecution(executor, "Plattform", i);
            }
        }
    }

    private static void measureExecution(ExecutorService executor, String info, int factor) {

        System.out.println("Start Measuring " + info);
        long start = System.nanoTime();

        try
        {
            for (int i = 0; i < 10 * factor; i++) {
                System.out.println("Start of " + info + " " + (i + 1) * 1000);
                submit1000Threads(executor);
            }
        }
        catch (Throwable th)
        {
            th.printStackTrace();
        }

        executor.close();
        System.out.println("End Measuring " + info);
        long end = System.nanoTime();
        System.out.println(info + " took " + (end-start) / 1_000_000 + " ms");
        System.out.println("-------------------------------");
    }


    private static void submit1000Threads(ExecutorService executor) {
        for (int  i = 0; i < 1_000; i++)
        {
            final int pos = i;
            executor.submit(() -> {
                Thread.sleep(Duration.ofSeconds(5));
                return pos;
            });
        }
    }
}
