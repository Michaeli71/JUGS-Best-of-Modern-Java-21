package exercises;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Exercise02_RecursiveRecordPatterns {

    public static void main(String[] args) {

        var p1 = new Point(1, 2);
        var p2 = new Point(3, 4);
        var p3 = new Point(5, 6);

        System.out.println(process(p1));
        System.out.println(process(new Line(p2, p3)));
        System.out.println(process(new Triangle(p1, p2, p3)));
    }

    static int process(Figure figure) {
        return switch (figure) {
            case Point(int x, int y) -> x * y;
            // TODO
            default -> throw new IllegalStateException("Unexpected value: " + figure);
        };
    }
}
