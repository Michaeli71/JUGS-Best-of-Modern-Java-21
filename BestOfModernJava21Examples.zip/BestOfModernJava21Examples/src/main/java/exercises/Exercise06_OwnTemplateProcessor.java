package exercises;

import static java.lang.StringTemplate.STR;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 *
 * @author Michael Inden
 *
 * Copyright 2023, 2024 by Michael Inden
 */
public class Exercise06_OwnTemplateProcessor {

    public static void main(String[] args)
    {
        String name = "Michael";
        int age = 52;

        System.out.println(DOUBLE_BRACES."Hello, \{name}! Next year, you'll be \{age + 1}.");

        System.out.println(DOUBLE_BRACES_IMP."Hello, \{name}! Next year, you'll be \{age + 1}.");

        System.out.println(enclose(">>>", "<<<")."Hello, \{name}! Next year, you'll be \{age + 1}.");

        System.out.println(f."Hello, \{name}! Next year, you'll be \{age + 1}.");
    }

    public static StringTemplate.Processor<String, RuntimeException> DOUBLE_BRACES =
            (StringTemplate template) -> {
                var result = new StringBuilder();

                return result.toString();
            };


    public static StringTemplate.Processor<String, RuntimeException> DOUBLE_BRACES_IMP = /* TODO */ STR;


    public static StringTemplate.Processor<String, RuntimeException> enclose(String left, String right) {
        return /* TODO */ STR;
    }

    public static StringTemplate.Processor<String, RuntimeException> f = STR;
}
