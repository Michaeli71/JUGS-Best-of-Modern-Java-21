package preview.api;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.StructuredTaskScope;

// Java 20
// import jdk.incubator.concurrent.StructuredTaskScope;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 17 / 18 / 19 / 20"
 * sowie die Bücher "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und
 * "Java 21 LTS – Die Neuerungen"
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2023 by Michael Inden
 */
public class StructuredConcurrency {
	public static void main(String[] args) throws ExecutionException, InterruptedException {
		System.out.println("Start");

		//System.out.println("sync:" + handleSynchronously(4711L));
		System.out.println("old style:" + handleOldStyle(4711L));
		//System.out.println("new style:" + handle(4711L));

		System.out.println("End");
	}

	static Response handleSynchronously(Long userId) throws InterruptedException {
		String user = findUser(userId);
		List<Order> order = fetchOrders(userId);

		return new Response(user, order);
	}

	static Response handleOldStyle(Long userId) throws ExecutionException, InterruptedException {
		var executorService = Executors.newCachedThreadPool();

		var userFuture = executorService.submit(() -> findUser(userId));
		var ordersFuture = executorService.submit(() -> fetchOrders(userId));

//		var user =  userFuture.get();// Join findUser
//		var orders = ordersFuture.get(); // Join fetchOrders

		return new Response(userFuture.get(), ordersFuture.get());
	}

	static Response handle(Long userId) throws ExecutionException, InterruptedException {
		try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {
			var userSubtask = scope.fork(() -> findUser(userId));
			var ordersSubtask = scope.fork(() -> fetchOrders(userId));

			scope.join(); // Join both forks
			scope.throwIfFailed(); // ... and propagate errors

			// Here, both forks have succeeded, so compose their results
			return new Response(userSubtask.get(), ordersSubtask.get());
		}
	}

	static String findUser(Long userId) throws InterruptedException {
		Thread.sleep(Duration.ofSeconds(4));
		System.out.println("findUser finished");
		return "Michael";
	}

	static List<Order> fetchOrders(Long userId) throws InterruptedException {
		Thread.sleep(Duration.ofSeconds(1));
		if (true)
			throw new IllegalStateException("JUST TO PROVIDE EX");
		return List.of();
	}

	record Order(String orderNo, List<String> items) {
	}

	record Response(String user, List<Order> orders) {
	}
}
