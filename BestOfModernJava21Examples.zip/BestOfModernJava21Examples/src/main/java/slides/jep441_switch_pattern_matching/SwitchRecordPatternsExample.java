package slides.jep441_switch_pattern_matching;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2023, 2024 by Michael Inden
 */
public class SwitchRecordPatternsExample
{
   public static void main(String[] args)
    {
        recordPatternsAndMatching(new Pos3D(7,2, 71));
        recordPatternsAndMatching(new Pos3D(7,2, 0));
        recordPatternsAndMatching(RgbColor.GREEN);
        recordPatternsAndMatching("MICHAEL");
    }

    record Pos3D(int x, int y, int z) {
    }

    enum RgbColor {RED, GREEN, BLUE}

    static void recordPatternsAndMatching(Object obj)
    {
        switch (obj)
        {
            case RgbColor color when color == RgbColor.RED ->
                    System.out.println("RED WARNING");
            case RgbColor color -> System.out.println("Enum: " + color);
            case Pos3D pos when pos.z() == 0 ->
                    System.out.println("Record: " + pos);
            case Pos3D(int x, int y, int z) when y > 0 ->
                    System.out.println("Record decomposed: " + x + ", " +
                            y + ", " + z);
            default -> System.out.println("Something else");
        }
    }
}
