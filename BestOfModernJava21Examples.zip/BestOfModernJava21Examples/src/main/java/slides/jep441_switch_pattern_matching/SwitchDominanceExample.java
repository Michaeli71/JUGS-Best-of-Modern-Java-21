package slides.jep441_switch_pattern_matching;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2023, 2024 by Michael Inden
 */
public class SwitchDominanceExample {

    public static void main(String[] args) {
        Integer value = calcValue();
        switch (value) {
            case -1, 0, 1 -> System.out.println("Handle special cases -1, 0 or 1");
            case Integer i when i >= 1 -> System.out.println("Handle positive integer cases i > 1");
            case Integer i -> System.out.println("Handle all the remaining integers");
        }

        recordPatternsAndMatching(RgbColor.RED);
        recordPatternsAndMatching(new Pos3D(0, 2, 7));
    }

    record Pos3D(int x, int y, int z) {
    }

    enum RgbColor {RED, GREEN, BLUE}

    static void recordPatternsAndMatching(Object obj) {
        switch (obj) {
            case RgbColor color when color == RgbColor.RED -> System.out.println("RED WARNING");
            case Pos3D pos when pos.z() == 0 -> System.out.println("Record: " + pos);
            case Pos3D(int x, int y, int z) when y > 0 && z > 6 ->
                    System.out.println("Record decomposed: " + x + ", " + y + ", " + z);
            default -> System.out.println("Something else");
        }
    }

    static int calcValue() {
        return 4711;
    }

    static void dominanceExample(Object obj) {
        switch (obj) {
            case null -> System.out.println("null");
            case String str -> System.out.println(str.toLowerCase());
            case Integer i -> System.out.println(i * i);
            default -> {
            }
        }
    }

    // Fehler im Eclipse-Compiler bei Dominance-Check, unreachable wird nicht erkannt
    static void dominanceExampleWithConstant(Object obj) {
        switch (obj.toString()) {
            case "Sophie" -> System.out.println("My lovely daughter");
            case String str when str.length() > 5 -> System.out.println(str.strip());
            default -> System.out.println("FALLBACK");
        }
    }
}