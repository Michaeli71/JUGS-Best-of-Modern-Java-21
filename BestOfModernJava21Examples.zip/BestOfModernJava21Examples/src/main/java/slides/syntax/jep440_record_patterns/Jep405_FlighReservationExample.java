package slides.syntax.jep440_record_patterns;

import java.time.Duration;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023, 2024 by Michael Inden
 */
public class Jep405_FlighReservationExample {

    record Person(String firstname, String lastname, LocalDate birthday) {
    }

    record Phone(String areaCode, String number) {
    }

    record City(String name, String country, String languageCode) {
    }

    record FlightReservation(Person person, Phone phoneNumber, City origin, City destination) {
    }


    static boolean checkAgeAndDestinationLanguageCorrectOld(Object obj) {
        if (obj instanceof FlightReservation reservation) {
            System.out.println("is a FlightReservation");
            if (reservation.person() != null) {
                System.out.println("has a person -- collection info");
                Person person = reservation.person();
                LocalDate birthday = person.birthday();

                if (reservation.destination() != null) {
                    System.out.println("has a destination -- collection info");
                    City destination = reservation.destination();
                    String languageCode = destination.languageCode();

                    if (birthday != null && languageCode != null) {
                        long years = ChronoUnit.YEARS.between(birthday, LocalDate.now());
                        return years >= 18 && List.of("EN", "DE", "FR").contains(languageCode);
                    }
                }
            }
        }
        System.out.println("no match 0");
        return false;
    }

    static boolean checkAgeAndDestinationLanguageCorrectNew(Object obj) {
        if (obj instanceof FlightReservation(
                Person(String firstname, String lastname, LocalDate birthday),
                Phone phoneNumber, City origin,
                City(String name, String country, String languageCode)
        )) {
            if (birthday != null && languageCode != null) {
                long years = ChronoUnit.YEARS.between(birthday, LocalDate.now());

                return years >= 18 && List.of("EN", "DE", "FR").contains(languageCode);
            }
        }
        System.out.println("no match 1");
        return false;
    }

    static boolean checkAgeAndDestinationLanguageCorrectNewV2(Object obj) {
        if (obj instanceof FlightReservation(
                Person(var _dc1, String _dc2, LocalDate birthday),
                Phone _dc_phoneNumber, City _dc_origin,
                City(var name, var country, var languageCode)
        )) {
            if (birthday != null && languageCode != null) {
                long years = ChronoUnit.YEARS.between(birthday, LocalDate.now());

                return years >= 18 && List.of("EN", "DE", "FR").contains(languageCode);
            }
        }
        System.out.println("no match 2");
        return false;
    }

    public static void main(String[] args) {
        var michael = new Person("Michael", "Inden", LocalDate.of(1971, 2, 7));
        var phone = new Phone("0049", "123244567");
        var zurich = new City("Zürich", "Switzerland", "CH");
        var stuhr = new City( "Stuhr", "Germany", "DE");

        var journey = new FlightReservation(michael, phone, null, zurich);
        var journey2 = new FlightReservation(michael, phone, null, zurich);
        var journey3 = new FlightReservation(michael, phone, null, stuhr);
        var journey4 = new FlightReservation(michael, phone, null, null);

        System.out.println(checkAgeAndDestinationLanguageCorrectOld(journey));
        System.out.println(checkAgeAndDestinationLanguageCorrectOld(journey2));
        System.out.println(checkAgeAndDestinationLanguageCorrectOld(journey3));
        System.out.println(checkAgeAndDestinationLanguageCorrectNew(journey));
        System.out.println(checkAgeAndDestinationLanguageCorrectNew(journey2));
        System.out.println(checkAgeAndDestinationLanguageCorrectNew(journey3));
        System.out.println(checkAgeAndDestinationLanguageCorrectNewV2(journey));
        System.out.println(checkAgeAndDestinationLanguageCorrectNewV2(journey2));
        System.out.println(checkAgeAndDestinationLanguageCorrectNewV2(journey3));

        // invalid
        System.out.println("Checking invalid destination");
        System.out.println(checkAgeAndDestinationLanguageCorrectOld(journey4));
        System.out.println(checkAgeAndDestinationLanguageCorrectNew(journey4));
        System.out.println(checkAgeAndDestinationLanguageCorrectNewV2(journey4));
    }
}
