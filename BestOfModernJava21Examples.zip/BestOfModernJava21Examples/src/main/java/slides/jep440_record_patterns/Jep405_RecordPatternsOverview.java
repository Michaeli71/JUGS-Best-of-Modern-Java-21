package slides.jep440_record_patterns;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2023 by Michael Inden
 */
public class Jep405_RecordPatternsOverview {
    public static void main(final String[] args) {
        record StringIntPair(String name, int value) {
        }

        Object obj = new StringIntPair("Michael", 52);

        // 1. Pattern Matching for instanceof
        if (obj instanceof StringIntPair pair) {
            System.out.println("object is a StringIntPair, name = " +
                    pair.name() + ", value = " + pair.value());
        }

        // 2. Record Pattern
        if (obj instanceof StringIntPair(String name, int value)) {
            System.out.println("object is a StringIntPair, " +
                    "name = " + name + ", value = " + value);
        }

// 3. Named Record Pattern
/*
if (obj instanceof StringIntPair(String name, int value) pair) {
    System.out.println("object is a StringIntPair, name = " +
            pair.name() + ", value = " + pair.value() +
            "name = " + name + ", value = " + value);
}
*/
    }
}
