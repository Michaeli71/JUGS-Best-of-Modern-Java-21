package solutions;

import java.util.*;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023, 2024 by Michael Inden
 */
public class Exercise04_SequencedCollections {
    public static void main(final String[] args)
    {
        primeNumbers();
    }

private static void primeNumbers()
{
    SequencedCollection<Integer> primeNumbers = new ArrayList<>();
    primeNumbers.add(3); // [3]
    primeNumbers.addFirst(2); // [2, 3]
    primeNumbers.addAll(List.of(5, 7, 11)); // [2, 3, 5, 7, 11]
    primeNumbers.addLast(13); // [2, 3, 5, 7, 11, 13]

    System.out.println(primeNumbers); // [2, 3, 5, 7, 11, 13]
    System.out.println(primeNumbers.getFirst()); // 2
    System.out.println(primeNumbers.getLast()); // 13
    System.out.println(primeNumbers.reversed()); // [13, 11, 7, 5, 3, 2]

    primeNumbers.addLast(17);
    System.out.println(primeNumbers); // [2, 3, 5, 7, 11, 13, 17]
    System.out.println(primeNumbers.reversed()); // [17, 13, 11, 7, 5, 3, 2]
}

private static void createABCSet()
{
    SequencedSet<String> numbers = new LinkedHashSet<>();
    numbers.addFirst("B"); // [B]
    numbers.addFirst("A"); // [A, B]
    numbers.addLast("C"); // [A, B, C]
    System.out.println(numbers);

    System.out.println(numbers.getFirst()); // A
    System.out.println(numbers.getLast()); // C
    System.out.println(numbers.reversed()); // [C, B, A]

}
}
