package solutions;

import java.util.LinkedHashSet;
import java.util.SequencedSet;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Exercise04_SequencedSet {
    public static void main(String[] args) {
        SequencedSet<String> numbers = new LinkedHashSet<>();
        numbers.add("B"); // [B]
        numbers.addFirst("A"); // [A, B]
        numbers.addLast("C"); // [A, B, C]
        System.out.println(numbers);

        System.out.println(numbers.getFirst()); // A
        System.out.println(numbers.getLast()); // C
        System.out.println(numbers.reversed()); // [C, B, A]
    }
}
