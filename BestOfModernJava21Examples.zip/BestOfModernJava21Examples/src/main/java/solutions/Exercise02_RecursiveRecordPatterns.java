package solutions;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2023, 2024 by Michael Inden
 */
public class Exercise02_RecursiveRecordPatterns {

    public static void main(String[] args) {

        var p1 = new Point(1, 2);
        var p2 = new Point(3, 4);
        var p3 = new Point(5, 6);

        System.out.println(process(p1));
        System.out.println(process(new Line(p2, p3)));
        System.out.println(process(new Triangle(p1, p2, p3)));
    }

    static int process(final Figure figure) {
        return switch (figure) {
            case Point(int x, int y) -> x * y;
            case Line(Point start, Point end) -> process(start) + process(end);
            case Triangle(Point a, Point b, Point c) -> process(a) + process(b) + process(c);
        };
    }

}
