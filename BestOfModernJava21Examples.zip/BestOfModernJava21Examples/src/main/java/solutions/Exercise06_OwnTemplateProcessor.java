package solutions;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 *
 * @author Michael Inden
 *
 * Copyright 2023 by Michael Inden
 */
public class Exercise06_OwnTemplateProcessor {

    public static void main(String[] args)
    {
        String name = "Michael";
        int age = 52;

        System.out.println(DOUBLE_BRACES."Hello, \{name}! Next year, you'll be \{age + 1}.");

        System.out.println(DOUBLE_BRACES_IMP."Hello, \{name}! Next year, you'll be \{age + 1}.");

        System.out.println(enclose(">>>", "<<<")."Hello, \{name}! Next year, you'll be \{age + 1}.");

        System.out.println(f."Hello, \{name}! Next year, you'll be \{age + 1}.");
    }

    public static StringTemplate.Processor<String, RuntimeException> DOUBLE_BRACES =
            (StringTemplate template) -> {
                var result = new StringBuilder();
                for (int i = 0; i < template.fragments().size(); i++) {
                    result.append(template.fragments().get(i));

                    if (i < template.values().size()) {
                        result.append("[[");
                        result.append("" + template.values().get(i));
                        result.append("]]");
                    }
                }
                return result.toString();
            };


    public static StringTemplate.Processor<String, RuntimeException> DOUBLE_BRACES_IMP =
            template -> {
                var convertedValues = template.values().stream().map(value -> "[[" + value + "]]").toList();

                return StringTemplate.interpolate(template.fragments(), convertedValues);
            };


    public static StringTemplate.Processor<String, RuntimeException> enclose(String left, String right) {
        return template -> {
            var convertedValues = template.values().stream().map(value -> left + value + right).toList();

            return StringTemplate.interpolate(template.fragments(), convertedValues);
        };
    }

    public static StringTemplate.Processor<String, RuntimeException> f =
            template -> {
                return StringTemplate.interpolate(template.fragments(), template.values());
            };
}
