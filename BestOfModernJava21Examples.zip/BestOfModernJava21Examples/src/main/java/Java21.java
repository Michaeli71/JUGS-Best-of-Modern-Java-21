/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021/22/23 by Michael Inden
 */
public class Java21 {

    public static void main(String[] args) { 
        multiMatch("Python");
        multiMatch(null);
        multiMatch(7);

        record Person(String name, int age) {}
        multiMatch(new Person("Michael", 52));
    }

    static void multiMatch(Object obj) {
        switch (obj) {
            case null -> System.out.println("null");
            case String str when str.length() > 5 -> System.out.println(str.toUpperCase());
            case String str  -> System.out.println(str.toLowerCase());
            case Integer i -> System.out.println(i * i);
            default -> throw new IllegalArgumentException("Unsupported type " + obj.getClass());
        }
    }
}